# Keywordshitter2 - The Bulk Keyword Tool

An update of the beloved keyword generation tool keywordshitter.com. [Try it here.](http://wassname.github.io/keywordshitter2/).

#New features:

- View the results as a sortable table
- Control how the keywords are branched
- Cache to a local database
- Settings

## Old-but-still-good features:

- Shit theme
- Simple
- Humor suitable for a toddler
- Cunningly lower user expectations to zero, then exceed them

## Coming soon (TM):

- Multiple services
- Updated toilet logo
- Less bugs
- CPC and Volume integration possibly


# License

MIT Licence (unless blakamia says otherwise)

# Contributing

Yes please.

# Credits

- [blakamia for being the reason we can't have nice things, and for creating the original keywordshitter](http://www.blackhatworld.com/blackhat-seo/black-hat-seo-tools/538215-free-simple-longtail-keyword-tool.html)
- wassname - for also being terrible.
